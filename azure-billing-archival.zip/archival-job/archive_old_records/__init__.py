import datetime
import json
import logging
import os
from azure.cosmos import CosmosClient
from azure.storage.blob import BlobServiceClient
import azure.functions as func

COSMOS_ENDPOINT = os.getenv('COSMOS_ENDPOINT')
COSMOS_KEY = os.getenv('COSMOS_KEY')
COSMOS_DB = os.getenv('COSMOS_DB')
COSMOS_CONTAINER = os.getenv('COSMOS_CONTAINER')
BLOB_CONN_STRING = os.getenv('BLOB_CONN_STRING')
BLOB_CONTAINER = os.getenv('BLOB_CONTAINER')

cosmos_client = CosmosClient(COSMOS_ENDPOINT, COSMOS_KEY)
container = cosmos_client.get_database_client(COSMOS_DB).get_container_client(COSMOS_CONTAINER)
blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONN_STRING)
blob_client = blob_service_client.get_container_client(BLOB_CONTAINER)

def main(mytimer: func.TimerRequest) -> None:
    cutoff = datetime.datetime.utcnow() - datetime.timedelta(days=90)
    query = f"SELECT * FROM c WHERE c.timestamp < '{cutoff.isoformat()}'"

    for item in container.query_items(query, enable_cross_partition_query=True):
        blob_name = f"{item['id']}.json"
        blob_client.upload_blob(blob_name, json.dumps(item), overwrite=True)
        container.delete_item(item['id'], partition_key=item['id'])

    logging.info("Archival job completed.")
