import logging
import azure.functions as func
import os
import json
from azure.cosmos import CosmosClient, exceptions
from azure.storage.blob import BlobServiceClient

COSMOS_ENDPOINT = os.getenv('COSMOS_ENDPOINT')
COSMOS_KEY = os.getenv('COSMOS_KEY')
COSMOS_DB = os.getenv('COSMOS_DB')
COSMOS_CONTAINER = os.getenv('COSMOS_CONTAINER')

BLOB_CONN_STRING = os.getenv('BLOB_CONN_STRING')
BLOB_CONTAINER = os.getenv('BLOB_CONTAINER')

cosmos_client = CosmosClient(COSMOS_ENDPOINT, COSMOS_KEY)
container = cosmos_client.get_database_client(COSMOS_DB).get_container_client(COSMOS_CONTAINER)
blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONN_STRING)
blob_client = blob_service_client.get_container_client(BLOB_CONTAINER)

def main(req: func.HttpRequest) -> func.HttpResponse:
    record_id = req.route_params.get('record_id')
    try:
        record = container.read_item(item=record_id, partition_key=record_id)
        return func.HttpResponse(json.dumps(record), status_code=200)
    except exceptions.CosmosResourceNotFoundError:
        try:
            blob_data = blob_client.get_blob_client(f"{record_id}.json").download_blob().readall()
            return func.HttpResponse(blob_data, status_code=200)
        except Exception as e:
            logging.error(f"Blob not found: {e}")
            return func.HttpResponse("Record not found", status_code=404)
