# Azure Billing Records Cost Optimization

## Overview
This project reduces storage costs in Azure by archiving billing records from Cosmos DB to Azure Blob Storage using serverless functions.

## Features
- Serverless Azure Functions
- Cosmos DB (hot data) + Blob Storage (cold data)
- Timer-triggered archival
- Transparent read-through logic

## Deployment
1. Fill in your Azure resource values in `deploy.ps1`
2. Run PowerShell script to deploy
3. Schedule archival job with Azure Functions

## License
MIT
