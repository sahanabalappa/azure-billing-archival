$resourceGroup = "BillingArchiveRG"
$storageAccount = "billingarchive${RANDOM}"
$functionApp = "billingFuncApp${RANDOM}"
$location = "eastus"

az group create --name $resourceGroup --location $location
az storage account create --name $storageAccount --resource-group $resourceGroup --location $location --sku Standard_LRS

az functionapp create --resource-group $resourceGroup --consumption-plan-location $location --runtime python --functions-version 4 --name $functionApp --storage-account $storageAccount

az functionapp config appsettings set --name $functionApp --resource-group $resourceGroup --settings \
COSMOS_ENDPOINT="<your-cosmos-endpoint>" \
COSMOS_KEY="<your-cosmos-key>" \
COSMOS_DB="BillingDB" \
COSMOS_CONTAINER="Records" \
BLOB_CONN_STRING="<your-blob-connection-string>" \
BLOB_CONTAINER="billing-archive"
